FREE FIRE PANEL STORE — SEPARATED ADMIN

Files:
1. free_fire_panel_store.html
   Public customer storefront.

2. admin.html
   Separate admin login/order-management page.

Important:
This is still a static HTML demo. Separating admin.html hides the admin page
from the normal storefront, but it does NOT provide real authentication security.
Anyone who obtains the admin page/code can inspect the frontend.

For a production site:
- Use server-side authentication.
- Store orders in a server/database.
- Keep admin credentials server-side.
- Approve/reject payments on the server.
- Only deliver files after server-side approval.
